export type UserRole = "coach" | "player" | "fan" | "admin";
export type UserPlan = "free" | "pro" | "team" | "school";

export interface UserProfile {
  id: string;
  email: string;
  displayName: string;
  role: UserRole;
  plan: UserPlan;
  tacticalRating: number;
  streakDays: number;
  preferredStyle: string[];
  createdAt: string;
}

export interface Player {
  id: string; // e.g. "player-1"
  name: string;
  number: number;
  role: "GK" | "DEF" | "MID" | "ATT";
  positionName: string; // e.g., "CB", "LW", "ST"
  x: number; // 0 to 100 on the pitch coordinate grid
  y: number; // 0 to 100 on the pitch coordinate grid
  speed?: number;
  passing?: number;
  positioning?: number;
  defending?: number;
  shooting?: number;
  stamina?: number;
}

export interface TacticalArrow {
  id: string;
  fromId: string; // ID of player or custom coordinate point
  toX: number;
  toY: number;
  type: "pass" | "run" | "press"; // pass is dashed/solid arrow, run is animated arc, press is red arrow
  color: "green" | "blue" | "red";
}

export interface PressZone {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  type: "circle" | "rectangle";
}

export interface DefensiveLine {
  y: number; // defensive line height coordinate (0 to 100)
  visible: boolean;
}

export interface TextLabel {
  id: string;
  text: string;
  x: number;
  y: number;
}

export interface CanvasData {
  players: Player[];
  arrows: TacticalArrow[];
  zones: PressZone[];
  defensiveLine: DefensiveLine;
  labels: TextLabel[];
}

export interface TacticPhase {
  id: string;
  name: "Build-up" | "Attack" | "Defence" | string;
  canvasData: CanvasData;
}

export interface Tactic {
  id: string;
  title: string;
  formation: string; // e.g., "4-3-3", "3-5-2"
  phases: TacticPhase[];
  activePhaseId: string;
  styleTags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface FootballMatch {
  id: string;
  opponentName: string;
  date: string;
  scoreHome: number;
  scoreAway: number;
  formationUsed: string;
  coachNotes: string;
  aiDebrief?: string;
}

export interface SessionDrill {
  name: string;
  duration: number; // in minutes
  description: string;
  coachingCues: string[];
  equipment: string[];
}

export interface TrainingSession {
  id: string;
  goalText: string;
  durationMins: number;
  playerCount: number;
  drills: SessionDrill[];
  createdAt: string;
}

export interface MatchSimulationInput {
  homeFormation: string;
  awayFormation: string;
  homeStyle: "Press" | "Possession" | "Counter" | "Low Block";
  awayStyle: "Press" | "Possession" | "Counter" | "Low Block";
  homeAdvantage: "Even" | "Home" | "Away";
  missingPlayer: boolean;
}

export interface SimulationResult {
  possessionHome: number;
  possessionAway: number;
  pressSuccessHome: number;
  pressSuccessAway: number;
  spaceInFinalThird: "Low" | "Medium" | "High";
  vulnerableZones: {
    x: number;
    y: number;
    width: number;
    height: number;
    name: string;
    description: string;
  }[];
  aiNarrative: string;
  suggestedAdjustment: string;
}

export interface CoachMessage {
  id: string;
  sender: "user" | "ai";
  text: string;
  timestamp: string;
}
