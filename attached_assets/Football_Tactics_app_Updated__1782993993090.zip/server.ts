import express from "express";
import path from "path";
import dotenv from "dotenv";
import fs from "fs";
import JSZip from "jszip";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini safely with lazy loading / error checks
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    // Return null or throw clear instructions - we will handle this gracefully in endpoints
    return null;
  }
  return new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// --- Football Tactical Rule-based Model ---
interface SimStats {
  possessionHome: number;
  possessionAway: number;
  pressSuccessHome: number;
  pressSuccessAway: number;
  spaceInFinalThird: "Low" | "Medium" | "High";
  vulnerableZones: { name: string; description: string; x: number; y: number; width: number; height: number }[];
}

function runTacticalSimulation(
  homeForm: string,
  awayForm: string,
  homeStyle: string,
  awayStyle: string,
  homeAdvantage: string
): SimStats {
  // Base stats
  let posH = 50;
  let pressH = 50;
  let pressA = 50;
  let spaceThird: "Low" | "Medium" | "High" = "Medium";
  const zones: SimStats["vulnerableZones"] = [];

  // 1. Formation Interactions
  if (homeForm === "3-5-2" && awayForm === "4-3-3") {
    // 3-5-2 wingbacks overload 4-3-3 wide areas but leave flanks exposed on transition
    posH += 5;
    zones.push({
      name: "Wide Flanks (Behind Wingbacks)",
      description: "Away wingers can exploit spaces behind wingbacks on quick transition.",
      x: 10,
      y: 35,
      width: 15,
      height: 30,
    });
  } else if (homeForm === "4-3-3" && awayForm === "3-5-2") {
    posH -= 5;
    zones.push({
      name: "Half-spaces",
      description: "Away dual strikers and advanced midfielders can overload the channel between fullback and centerback.",
      x: 25,
      y: 40,
      width: 20,
      height: 20,
    });
  }

  if (homeForm === "4-2-3-1" && awayForm === "4-4-2") {
    // Double pivot controlled midfield
    posH += 8;
  } else if (homeForm === "4-4-2" && awayForm === "4-2-3-1") {
    posH -= 8;
  }

  // 2. Tactical Style Interactions
  if (homeStyle === "Possession") {
    posH += 10;
  }
  if (awayStyle === "Possession") {
    posH -= 10;
  }

  if (homeStyle === "Press") {
    pressH += 15;
    if (awayStyle === "Possession") {
      // High press disrupts possession
      posH -= 5;
      pressH += 5;
    }
  }
  if (awayStyle === "Press") {
    pressA += 15;
    if (homeStyle === "Possession") {
      posH += 5;
      pressA += 5;
    }
  }

  if (homeStyle === "Low Block") {
    posH -= 12;
    spaceThird = "Low";
    zones.push({
      name: "Deep Box",
      description: "Congested center of the box makes central entries difficult; forces opponent wide.",
      x: 35,
      y: 75,
      width: 30,
      height: 15,
    });
  }
  if (awayStyle === "Low Block") {
    posH += 12;
    spaceThird = "Low";
    zones.push({
      name: "Opponent Low Block Core",
      description: "Squeeze central lanes. Requires shifting ball side-to-side to create gaps.",
      x: 35,
      y: 15,
      width: 30,
      height: 15,
    });
  }

  // 3. Advantage
  if (homeAdvantage === "Home") {
    posH += 3;
    pressH += 5;
  } else if (homeAdvantage === "Away") {
    posH -= 3;
    pressA += 5;
  }

  // Bound stats safely between 10% and 90%
  posH = Math.max(15, Math.min(85, posH));
  pressH = Math.max(20, Math.min(90, pressH));
  pressA = Math.max(20, Math.min(90, pressA));

  // Determine standard zones if empty
  if (zones.length === 0) {
    zones.push({
      name: "Midfield Pocket",
      description: "Zone of active transition and turnovers.",
      x: 40,
      y: 45,
      width: 20,
      height: 15,
    });
  }

  return {
    possessionHome: posH,
    possessionAway: 100 - posH,
    pressSuccessHome: pressH,
    pressSuccessAway: pressA,
    spaceInFinalThird: spaceThird,
    vulnerableZones: zones,
  };
}

// --- Express API Routes ---

// 1. AI Coach on the Tactics Board
app.post("/api/gemini/coach", async (req, res) => {
  const { messages, activeTactic, currentPhase, prompt } = req.body;
  
  const formation = activeTactic?.formation || "4-3-3";
  const title = activeTactic?.title || "Untitled Tactic";
  const phaseName = currentPhase?.name || "Attack";
  const userPrompt = prompt || "Analyze my current formation and give a suggestion.";

  const getDynamicLocalCoachAdvice = () => {
    const fallbacks = [
      `TactIQ Coach (Local Mode): For your current ${formation} formation in the ${phaseName} phase, ensure your central pivot players are positioned defensively to prevent quick counters. If the opposition plays a low block, encourage fullbacks to push high and offer width to stretch their compact lines. Shall we add a specific high press zone on the board to visualize our recovery triggers?`,
      `TactIQ Coach (Local Mode): Looking at your "${title}" (${formation}) layout during the ${phaseName} phase, my top recommendation is to ensure your wingers and advanced midfielders coordinate to create overloads in the half-spaces. Keep the defensive line high to compress space between the lines. How would you like to tweak the pressing zone or player positions to support this?`,
      `TactIQ Coach (Local Mode): On this ${formation} setup for "${title}", the defensive line height is critical during the ${phaseName} phase. Ensure the central defenders drop quickly if the opponent bypasses your first line of press. Would you like to adjust the player roles or rename any note labels to make these instructions clearer?`
    ];
    return fallbacks[Math.abs(userPrompt.length) % fallbacks.length];
  };

  const ai = getGeminiClient();
  if (!ai) {
    return res.json({ text: getDynamicLocalCoachAdvice() });
  }

  try {
    const systemInstruction = `You are TactIQ AI, an elite professional football tactics coach and senior match analyst. 
You speak directly, constructively, and specifically — just like an experienced manager on the training ground.
Never give vague, generic, or flowery advice. 
Strictly enforce a MAXIMUM limit of 120 words.
Always end with exactly one direct, actionable prompt/question to guide the coach to their next tactical move.
You have full context of the coach's current board:
- Tactic Title: "${title}"
- Active Formation: "${formation}"
- Active Phase: "${phaseName}"
Use this context to address the user's inquiry. If the user hasn't asked anything, they may have triggered an 8-second idle nudge. In that case, give a quick tactical suggestion for their formation.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.log("[TactIQ] Serving dynamic local coach response.");
    res.json({ text: getDynamicLocalCoachAdvice() });
  }
});

// 2. AI Match Simulator
app.post("/api/gemini/simulate", async (req, res) => {
  const { homeFormation, awayFormation, homeStyle, awayStyle, homeAdvantage, missingPlayer } = req.body;

  // Run the rule-based simulation engine first to get precise statistics
  const stats = runTacticalSimulation(homeFormation, awayFormation, homeStyle, awayStyle, homeAdvantage);

  const getDynamicLocalSimulation = () => {
    let narrative = `A captivating matchup unfolds as the home side deploys a ${homeFormation} (${homeStyle}) against the away team's ${awayFormation} (${awayStyle}). `;
    
    if (homeStyle === "Press" && awayStyle === "Possession") {
      narrative += `The home team's intense high-press block successfully disrupted the away team's patient build-up, forcing turnovers in key transition sectors with a ${stats.pressSuccessHome}% pressing success rate. `;
    } else if (homeStyle === "Possession" && awayStyle === "Press") {
      narrative += `Home's patient positional game with ${stats.possessionHome}% ball possession forced Away's pressing structures to shift constantly, opening up pockets of space in the half-spaces and wide channels. `;
    } else if (homeStyle === "Low Block") {
      narrative += `By maintaining a deep, disciplined defensive block, Home successfully congested central lanes, limiting space in the final third to "${stats.spaceInFinalThird}". `;
    } else {
      narrative += `Midfield duels dominated the flow, with Home maintaining ${stats.possessionHome}% possession while searching for gaps to exploit between the opponent's defensive lines. `;
    }

    if (missingPlayer) {
      narrative += `The suspension of the home team's key player noticeably slowed down fluid transitions, limiting central playmaking options. `;
    }

    let adjustment = "";
    if (homeStyle === "Possession") {
      adjustment = `Instruct fullbacks to overlap dynamically to stretch the opponent's defensive shape and create central entries.`;
    } else if (homeStyle === "Press") {
      adjustment = `Establish a structured mid-block resting shape during phases of low stamina to prevent quick counter-attacks.`;
    } else if (homeStyle === "Low Block") {
      adjustment = `Release quick winger runs immediately upon winning possession to bypass the opponent's advanced defensive lines.`;
    } else {
      adjustment = `Consider shifting to a 4-2-3-1 double pivot layout to establish secure midfield control and handle central overloads.`;
    }

    return {
      stats,
      aiNarrative: narrative.trim() + " [TactIQ Local Prediction Engine]",
      suggestedAdjustment: adjustment,
    };
  };

  const ai = getGeminiClient();
  if (!ai) {
    return res.json(getDynamicLocalSimulation());
  }

  try {
    const systemInstruction = `You are TactIQ AI, a world-class football tactical simulator. 
Based on the raw computed stats, formations, and styles, write an elite tactical narrative explaining precisely WHY the matchup results in these stats.
Use clear tactical concepts (overloads, transition traps, positional play, half-spaces).
Strictly keep the narrative around 120 words. 
Do not hallucinate random stats or scores; stick to the provided simulation statistics.
Also provide 1 specific, highly targeted tactical adjustment that the Home manager could execute to improve control.`;

    const prompt = `Matchup:
Home Team: ${homeFormation} playing a "${homeStyle}" style.
Away Team: ${awayFormation} playing a "${awayStyle}" style.
Advantage Parameter: ${homeAdvantage}.
Key player absence: ${missingPlayer ? "Yes, Home key player is suspended" : "No"}.

Calculated Match Stats:
- Possession: ${stats.possessionHome}% Home / ${stats.possessionAway}% Away
- Press success: ${stats.pressSuccessHome}% Home / ${stats.pressSuccessAway}% Away
- Space in Final Third: "${stats.spaceInFinalThird}"

Return a JSON object matching this schema:
{
  "aiNarrative": "A high-quality 120-word tactical description of the clash",
  "suggestedAdjustment": "A highly specific, one-sentence suggestion"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            aiNarrative: { type: Type.STRING },
            suggestedAdjustment: { type: Type.STRING },
          },
          required: ["aiNarrative", "suggestedAdjustment"],
        },
        temperature: 0.6,
      },
    });

    const result = JSON.parse(response.text?.trim() || "{}");
    res.json({
      stats,
      aiNarrative: result.aiNarrative,
      suggestedAdjustment: result.suggestedAdjustment,
    });
  } catch (error) {
    console.log("[TactIQ] Serving dynamic local simulator response.");
    res.json(getDynamicLocalSimulation());
  }
});

// 3. AI Training Session Builder
app.post("/api/gemini/training", async (req, res) => {
  const { goalText, durationMins, playerCount } = req.body;

  const getDynamicLocalTrainingSession = () => {
    return {
      goalText,
      durationMins,
      playerCount,
      drills: [
        {
          name: "Warm-up: Rondo 4v2 Passing",
          duration: Math.round(durationMins * 0.2),
          description: `Passing triangles inside a compact rondo grid to activate rapid transition triggers and spatial awareness, specifically targeting the objective: "${goalText}".`,
          coachingCues: ["Limit touches to 1 or 2", "Open body posture to scan surroundings", "Apply quick press upon possession loss"],
          equipment: ["4 Cones", "1 Match Ball", "2 Training Bibs"],
        },
        {
          name: "Core Theme: Tactical Positioning & Progression",
          duration: Math.round(durationMins * 0.5),
          description: `Structured transition play from the defensive third into wide channels to unlock space in the final third. Overload exercises to address your goal: "${goalText}".`,
          coachingCues: ["Wingers commit defenders to free up overlapping options", "Midfield pivot maintains balance", "Precise delivery into the penalty box"],
          equipment: ["10 Cones", "5 Training Balls", "2 Portable Goals"],
        },
        {
          name: "Match Scenario: Scrimmage with Restrictions",
          duration: Math.round(durationMins * 0.3),
          description: `Full scrimmage where goals are doubled if scored within 5 passes of winning possession, matching your tactical focus: "${goalText}".`,
          coachingCues: ["Defensive units squeeze vertical lanes", "Deliver instant forward outlet passes", "Patience when in established possession"],
          equipment: ["Cones", "Bibs", "Balls", "Goals"],
        },
      ],
      previewNote: "Offline fallback activated gracefully.",
    };
  };

  const ai = getGeminiClient();
  if (!ai) {
    return res.json(getDynamicLocalTrainingSession());
  }

  try {
    const systemInstruction = `You are TactIQ AI, an elite UEFA Pro license coaching educator.
Generate an outstanding, professional, structured football training session plan.
Generate a sequence of 3 highly logical drills that fit the session's overall goal:
1. Warm-up (20% duration)
2. Technical/Tactical Theme Drill (50% duration)
3. Conditioned Scrimmage (30% duration)
Each drill must include a professional name, precise duration (minutes, summing up to the overall constraint), specific setup description, actionable coaching cues, and required training equipment.
Format the output as a clean, structured JSON object matching the requested schema.`;

    const prompt = `Build a coaching session plan for:
- Goal: "${goalText}"
- Total Duration: ${durationMins} minutes
- Available Squad: ${playerCount} players.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            drills: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  duration: { type: Type.INTEGER },
                  description: { type: Type.STRING },
                  coachingCues: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  equipment: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                },
                required: ["name", "duration", "description", "coachingCues", "equipment"],
              },
            },
          },
          required: ["drills"],
        },
        temperature: 0.7,
      },
    });

    const result = JSON.parse(response.text?.trim() || "{}");
    res.json({
      goalText,
      durationMins,
      playerCount,
      drills: result.drills,
    });
  } catch (error) {
    console.log("[TactIQ] Serving dynamic local training session plan.");
    res.json(getDynamicLocalTrainingSession());
  }
});

// 4. Match Brain Insights
app.post("/api/gemini/insights", async (req, res) => {
  const { matches } = req.body;

  const getDynamicLocalInsights = () => {
    if (!matches || matches.length === 0) {
      return {
        insight: "Log your first weekend match to unlock personalized Match Brain insights! Your AI assistant will detect conceding channels and style flaws.",
        drillSuggestion: "Rondo 5v2 transition drill.",
      };
    }

    let totalGoalsConceded = 0;
    let totalGoalsScored = 0;
    let notesText = "";
    
    matches.forEach((m: any) => {
      totalGoalsConceded += m.scoreAway || 0;
      totalGoalsScored += m.scoreHome || 0;
      if (m.coachNotes) notesText += " " + m.coachNotes;
    });

    const formation = matches[0].formationUsed || "4-3-3";
    let insight = "";
    let drillSuggestion = "";

    if (totalGoalsConceded > totalGoalsScored) {
      insight = `Our analysis of your last ${matches.length} matches shows defensive lapses. Your ${formation} layout has conceded ${totalGoalsConceded} goals, frequently leaving the defensive lines isolated during direct transitions. Instruct fullbacks to delay opponent counters.`;
      drillSuggestion = "Overload Channel Defensive Recovery Grid";
    } else if (notesText.toLowerCase().includes("press") || notesText.toLowerCase().includes("trap")) {
      insight = `Excellent pressing records. Your tactical logs indicate highly coordinated defensive traps that successfully force opponent turnovers. Focus now on rapid vertical transition passes to punish unbalanced defensive lines.`;
      drillSuggestion = "Midfield Turnover Rapid Counter-Press Rondo";
    } else {
      insight = `Your team displays solid control in central areas using the ${formation} structure. However, building out under a high opponent press remains an area to perfect. Ensure defensive pivots drop deeper to offer passing angles.`;
      drillSuggestion = "Building out from the Back under High Press";
    }

    return {
      insight,
      drillSuggestion
    };
  };

  const ai = getGeminiClient();
  if (!ai) {
    return res.json(getDynamicLocalInsights());
  }

  try {
    const matchSummary = matches
      .map((m: any) => `vs ${m.opponentName}: Score ${m.scoreHome}-${m.scoreAway}, Formation: ${m.formationUsed}, Notes: ${m.coachNotes}`)
      .join("\n");

    const systemInstruction = `You are Match Brain, a professional analytics companion for grassroots and semi-pro football coaches.
Analyze the logged match history list and produce one highly targeted, personalized tactical observation (Today's Insight) that is directly tied to the match events, formations, or coach notes. 
Give actionable, elite coaching advice in a maximum of 90 words. 
Always recommend a single training drill name or theme to address this specific observation.`;

    const prompt = `Analyze this logged match history:\n${matchSummary}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            insight: { type: Type.STRING },
            drillSuggestion: { type: Type.STRING },
          },
          required: ["insight", "drillSuggestion"],
        },
        temperature: 0.6,
      },
    });

    const result = JSON.parse(response.text?.trim() || "{}");
    res.json(result);
  } catch (error) {
    console.log("[TactIQ] Serving dynamic local match brain insights.");
    res.json(getDynamicLocalInsights());
  }
});

// Helper function to recursively add directories to the JSZip instance
function addDirToZip(dirPath: string, zipInstance: JSZip, relativePath: string = "") {
  const items = fs.readdirSync(dirPath);
  for (const item of items) {
    if (
      item === "node_modules" ||
      item === "dist" ||
      item === ".git" ||
      item === ".next" ||
      item === "package-lock.json" ||
      item === ".cache" ||
      item === "dist-server"
    ) {
      continue;
    }
    const fullPath = path.join(dirPath, item);
    const itemRelativePath = relativePath ? `${relativePath}/${item}` : item;
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      addDirToZip(fullPath, zipInstance, itemRelativePath);
    } else {
      const fileContent = fs.readFileSync(fullPath);
      zipInstance.file(itemRelativePath, fileContent);
    }
  }
}

// Endpoint to download the entire project as a ZIP file
app.get("/api/export-project", async (req, res) => {
  try {
    const zip = new JSZip();
    addDirToZip(process.cwd(), zip);
    const content = await zip.generateAsync({ type: "nodebuffer" });
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", 'attachment; filename="tactiq-football-tactics.zip"');
    res.send(content);
  } catch (error) {
    console.log("[TactIQ] Export project ZIP handled.");
    res.status(500).send("Error exporting project ZIP.");
  }
});

// Vite / static file serving setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[TactIQ] Full-Stack server running on port ${PORT}`);
  });
}

startServer();
